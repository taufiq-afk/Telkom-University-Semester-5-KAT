Struktur Tabel Database

CREATE DATABASE scalable_app;

USE scalable_app;

CREATE TABLE user_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    input_value TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);