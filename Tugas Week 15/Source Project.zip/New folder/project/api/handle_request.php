<?php
// Include database configuration
require_once '../db/db_config.php';

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the user input from the form
    $userInput = trim($_POST['user_input']);

    if (!empty($userInput)) {
        try {
            // Prepare SQL query to insert user input into the database
            $stmt = $pdo->prepare("INSERT INTO user_data (input_value, created_at) VALUES (:input_value, NOW())");
            $stmt->bindParam(':input_value', $userInput);

            // Execute the query
            if ($stmt->execute()) {
                echo "Data successfully saved to the database.";
            } else {
                echo "Failed to save data. Please try again.";
            }
        } catch (PDOException $e) {
            echo "Database error: " . $e->getMessage();
        }
    } else {
        echo "Input cannot be empty.";
    }
} else {
    echo "Invalid request method.";
}
?>