<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scalable Web App</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to the Scalable Web App</h1>
        <form action="../api/handle_request.php" method="POST">
            <input type="text" name="user_input" placeholder="Enter some data" required>
            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>